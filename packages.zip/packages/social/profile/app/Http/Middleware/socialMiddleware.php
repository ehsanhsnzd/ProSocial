<?php
/**
 * Created by PhpStorm.
 * User: kousha
 * Date: 8/11/18
 * Time: 7:15 PM
 */

namespace social\profile\App\Http\Middleware;

use Closure;

class socialMiddleware {

    /**
         * social profile MIDDLEWARE
     *
     * @param $request
     * @param Closure $next
     *
     * @return Closure
     */
    public function handle($request,Closure $next){

        return $next($request);

    }

}