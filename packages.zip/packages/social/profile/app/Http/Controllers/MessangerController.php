<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MessangerController extends Controller
{
    //
}
