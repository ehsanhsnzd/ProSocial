<?php
/**
 * Created by PhpStorm.
 * User: kousha
 * Date: 8/11/18
 * Time: 4:58 PM
 */

namespace social\profile\App\Services;

use App\User;
use social\Core\App\Services\socialService;
use social\profile\app\Models\Profile;

class SocialProfileService extends socialService {

    public function createProfile(User $user){
        $oProfile = new Profile();
        $oProfile->user()->associate($user);

        return $oProfile;

    }

}