<?php

namespace social\profile\app\Models;

use Illuminate\Database\Eloquent\Model;

class profile extends Model
{
    /**
     * TABLE NAME
     *
     * @var string
     */
    protected $table = 'profiles';

    /**
     * PRIMARY KEY NAME
     *
     * @var string
     */
    protected $primaryKey = 'profile_id';

    /**
     * TABLES PROFILES
     *
     * @var array
     */
    protected $fillable = ['name','last_name','country_id','sate_id','city_id','username','zip','description','album_id','images_id','phone','address','email','is_active','created_at' ,'updated_at'];


    // Get Instant Messenger Of Profile

    public function messenger()
    {
    return $this->hasmany( messenger::class,'profile_id','profile_id');
    }


    public function user(){
        return $this->belongsTo(User::class,'user_id','id');
    }
}
