<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class education extends Model
{
    //
}
