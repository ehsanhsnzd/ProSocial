<?php
/**
 * Created by PhpStorm.
 * User: kousha
 * Date: 8/11/18
 * Time: 4:05 PM
 */
namespace social\profile\App\Providers;

use social\profile\App\Services\socialEmailService;
use social\profile\App\Services\socialErrorService;
use Illuminate\Foundation\AliasLoader;
use Illuminate\Support\ServiceProvider;
use social\profile\app\Services\SocialProfileService;


class socialProfileServiceProvider extends ServiceProvider
{

    public function register()
    {

        // BIND profile FACADE
        $this->app->bind('socialprofile', function () {
            return new SocialProfileService();
        });
        $this->app->bind('socialError', function () {
            return new socialErrorService();
        });
        $this->app->bind('socialEmail', function () {
            return new socialEmailService();
        });

        //INSERT PACKAGE FACADES
        AliasLoader::getInstance()->alias('socialprofile', \social\profile\App\Facades\socialprofileFacade::class);
        AliasLoader::getInstance()->alias('socialError', \social\profile\App\Facades\socialErrorFacade::class);
        AliasLoader::getInstance()->alias('socialEmail', \social\profile\App\Facades\socialEmailFacade::class);

        //INSERT PACKAGE CONFIG FILE
        $this->mergeConfigFrom(__DIR__ . '/../../config/socialprofile.php', 'socialprofile');

        //Register Dependence Packages
        $this->app->register(\PulkitJalan\Cache\Providers\MultiCacheServiceProvider::class);
        $this->app->register(\Laravel\Passport\PassportServiceProvider::class);
        $this->app->register(\Intervention\Image\ImageServiceProvider::class);

        //insert dependency package Facades
        AliasLoader::getInstance()->alias('Image',\Intervention\Image\Facades\Image::class);


    }

    public function boot()
    {
        //INSERT PACKAGE ROUTES
        $this->loadRoutesFrom(__DIR__ . '/../../routes/api.php');
        $this->loadRoutesFrom(__DIR__. '/../../routes/web.php');


        //PUBLISH PACKAGE CONFIG FILE
        $this->publishes([__DIR__ . '/../../config' => config_path(),], 'Configs');
        $this->publishes([__DIR__.'/../../database/Seeds/Publishes' => database_path('seeds')],'Seeds');
        $this->publishes([__DIR__.'/../../resources/Publishes' => resource_path()],'Views');


        //INSERT PACKAGE VIEW FILE
        $this->loadViewsFrom(__DIR__ . '/../../resources/Views', 'socialprofile');
        $this->loadViewsFrom(__DIR__ . '/../../resources/Emails', 'socialEmail');
        // Insert Package Migrations
        $this->loadMigrationsFrom(__DIR__ . '/../../database/Migrations');

        // INSERT PACKAGE MIDDLEWARE
        $this->app->router->aliasMiddleware('socialMiddleware', \social\profile\App\Http\Middleware\socialMiddleware::class);
        $this->app->router->aliasMiddleware('Cors',\social\profile\App\Http\Middleware\Cors::class);
        $this->app->router->aliasMiddleware('Json',\social\profile\App\Http\Middleware\Json::class);

    }

}