<?php
/**
 * Created by PhpStorm.
 * User: kousha
 * Date: 8/11/18
 * Time: 4:03 PM
 */

return array(
    'Active' => 1,
    'Client_Domain' => 'http://localhost:8080/#',
    'social_Auth' =>true
);