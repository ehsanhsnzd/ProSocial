<?php
/**
 * Created by PhpStorm.
 * User: Ehsan
 * Date: 8/11/18
 * Time: 4:01 PM
 */





Route::group(['namespace' => 'social\profile\App\Http\Controllers\API'], function () {
    Route::prefix('/api/')->middleware(['Cors','Json'])->group(function () {
        Route::post('login', 'UserController@login');
        Route::post('register', 'UserController@register');
        Route::post('resetPasswordEmail', 'UserController@ResetPasswordEmail');
        Route::post('verifyEmail','UserController@VerifyEmail');
        Route::post('resetPassword','UserController@ResetPassword');

        Route::group(['middleware' => 'auth:api'], function () {
            Route::post('details', 'UserController@details');
        });
    });
});

Route::group(['namespace' => 'social\profile\App\Http\Controllers'], function () {
    Route::prefix('/social/profile/api/')->middleware(['Cors','Json'])->group(function () {

        Route::group(['middleware' => ['auth:api','verified']], function(){

            Route::get('test','socialprofileController@test');

            Route::get('baseSettings','BaseSettingController@getAll');
            Route::get('baseSetting/{iId}','BaseSettingController@get');
            Route::post('baseSetting','BaseSettingController@set');
            Route::put('baseSetting/{iId}','BaseSettingController@update');
            Route::delete('baseSetting/{iId}','BaseSettingController@delete');

            Route::get('settings','SettingController@getAll');
            Route::get('setting/{iId}','SettingController@get');
            Route::post('setting','SettingController@set');
            Route::put('setting/{iId}','SettingController@update');
            Route::delete('setting/{iId}','SettingController@delete');

        });

    });
});