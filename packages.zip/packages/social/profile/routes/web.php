<?php
/**
 * Created by PhpStorm.
 * User: kousha
 * Date: 8/11/18
 * Time: 4:01 PM
 */

Route::group(['middleware' => ['MadMiddleware'], 'namespace' => 'social\profile\App\Http\Controllers'], function () {
    Route::prefix('/social/profile/')->middleware([])->group(function () {


    });
});