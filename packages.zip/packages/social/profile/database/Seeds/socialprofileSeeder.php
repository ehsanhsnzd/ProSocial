<?php
/**
 * Created by PhpStorm.
 * User: kousha
 * Date: 8/11/18
 * Time: 6:50 PM
 */


namespace social\profile\Database\Seeds;

use Illuminate\Database\Seeder;


class socialprofileSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $this->call(socialBaseSettingSeeder::class);
        $this->call(socialSettingSeeder::class);
    }
}
