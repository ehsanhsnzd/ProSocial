<?php
/**
 * Created by PhpStorm.
 * User: kousha
 * Date: 8/11/18
 * Time: 6:50 PM
 */


namespace social\profile\Database\Seeds;

use social\profile\App\Models\Setting;
use Illuminate\Database\Seeder;


class socialSettingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

    }
}
