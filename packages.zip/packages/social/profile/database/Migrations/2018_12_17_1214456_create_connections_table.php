<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateConnectionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('connections', function (Blueprint $table) {
            $table->increments('notification_id');
            $table->unsignedInteger('profile_from_id');
            $table->foreign("profile_from_id")->references("profile_id")->on("profiles")->onDelete('cascade');
            $table->unsignedInteger('profile_to_id');
            $table->foreign("profile_to_id")->references("profile_id")->on("profiles")->onDelete('cascade');
            $table->boolean('is_blocked')->default(false)->nullable(false);
            $table->boolean('is_accept')->default(false)->nullable(false);
            $table->boolean('is_active')->default(true)->nullable(false);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('connections');
    }
}
