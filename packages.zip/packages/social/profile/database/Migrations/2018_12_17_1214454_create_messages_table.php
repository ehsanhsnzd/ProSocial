<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMessagesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('messages', function (Blueprint $table) {
            $table->increments('message_id');
            $table->unsignedInteger('profile_from_id');
            $table->foreign("profile_from_id")->references("profile_id")->on("profiles")->onDelete('cascade');
            $table->unsignedInteger('profile_to_id');
            $table->foreign("profile_to_id")->references("profile_id")->on("profiles")->onDelete('cascade');
            $table->unsignedInteger('album_id');
            $table->foreign("album_id")->references("album_id")->on("albums")->onDelete('no action');
            $table->string("message")->nullable(false);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('messages');
    }
}
