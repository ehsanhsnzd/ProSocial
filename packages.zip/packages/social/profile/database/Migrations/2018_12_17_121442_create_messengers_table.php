<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMessengersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('messengers', function (Blueprint $table) {
            $table->increments('messenger_id');
            $table->unsignedInteger('profile_id');
            $table->foreign("profile_id")->references("profile_id")->on("profiles")->onDelete('cascade');
            $table->unsignedInteger("type_id");
            $table->foreign('type_id')->references('setting_id')->on('settings');
            $table->string("messenger_value")->nullable(false);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('messangers');
    }
}
